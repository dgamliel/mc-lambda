import boto3
import json
import os


def lambda_handler(event, context):

    # Get the latest AMI ID
    ec2 = boto3.resource('ec2')

    # List all instances
    instances = []
    for instance in ec2.instances.all():
        instances.append(instance.id)



    return {
        'statusCode': 200,
        'body': json.dumps(instances)
    }